/** Shared README section splitter (Suite A generator and fixture tests use the same code, so target titles agree). */
export type Section = { title: string; body: string };
export const cleanTitle = (t: string) => t.replace(/\[([^\]]*)\]\([^)]*\)/g, "$1").replace(/`/g, "").replace(/<[^>]+>/g, "").replace(/[^\w\s?'.+()\/:-]/g, "").replace(/\s+/g, " ").trim();
export function sectionize(doc: string): Section[] {
  const lines = doc.split("\n"); const secs: Section[] = []; let cur: Section = { title: "intro", body: "" };
  for (const line of lines) { const m = /^(#{1,3})\s+(.*)$/.exec(line); if (m && !(m[1] === "#" && secs.length === 0 && !cur.body.trim())) { secs.push(cur); cur = { title: cleanTitle(m[2]!), body: "" }; } else if (!m) cur.body += line + "\n"; }
  secs.push(cur); return secs.filter((s) => s.body.trim().length > 0);
}
